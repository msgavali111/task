document.addEventListener('DOMContentLoaded', function () {
    const tableBody = document.getElementById('tableBody');
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    const rows = Array.from(tableBody.querySelectorAll('tr'));
    const initialDisplayCount = 10;
    let displayedCount = 0;

    function showRows(count) {
        for (let i = displayedCount; i < displayedCount + count && i < rows.length; i++) {
            rows[i].classList.remove('hidden');
        }
        displayedCount += count;
        if (displayedCount >= rows.length) {
            loadMoreBtn.style.display = 'none';
        }
    }

    loadMoreBtn.addEventListener('click', function() {
        showRows(rows.length - displayedCount);
    });

    // Show initial records
    showRows(initialDisplayCount);
});
