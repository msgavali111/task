document.addEventListener("DOMContentLoaded", function() {
    var cards = document.querySelectorAll(".card");
    var contents = document.querySelectorAll(".parsys-container");

    cards.forEach(function(card) {
        card.addEventListener("click", function() {
            var targetId = this.getAttribute("data-target");

            // Deactivate all cards
            cards.forEach(function(c) {
                c.classList.remove("active");
            });

            // Activate clicked card
            this.classList.add("active");

            // Hide all content sections
            contents.forEach(function(content) {
                content.style.display = "none";
            });

            // Show the clicked content section
            var targetContent = document.getElementById(targetId);
            targetContent.style.display = "block";
        });
    });
});
